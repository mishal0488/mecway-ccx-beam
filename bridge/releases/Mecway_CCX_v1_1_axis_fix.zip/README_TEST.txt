MECWAY CCX BEAM BRIDGE v1.1 - I/C/L AXIS FIX

LOCAL TEST ONLY. DO NOT PUSH TO GITHUB.

WHAT v1.0.1 SHOWED
------------------
The model was globally in equilibrium, but Mecway and CCX had large
differences in displacements and support-force distribution.

ROOT CAUSE FOUND
----------------
For Mecway I, C and L sections, Mecway V/W uses the opposite transverse
section-axis ordering from the UB31 native I/CHAN/L geometry routines.

Example: 152x152x30 I section

  Mecway I about V = 5.603465e-6 m^4
  Mecway I about W = 1.725086e-5 m^4

  UB31 Iyy          = 1.725086e-5 m^4
  UB31 Izz          = 5.603465e-6 m^4

The numerical values are identical but assigned to opposite axes.

v1.1 therefore uses, for I/C/L profiles:

  UB31 final local y = Mecway W
  UB31 final local z = -Mecway V

L sections retain the additional compensation for UB31's internal
principal-axis rotation.

The global offset vector is transformed into this corrected final basis, so
the physical 1.8 m channel offsets remain in the same global direction.

MODEL COUNTS
------------
60  I-section elements
220 channel elements
80  L-angle elements

All 360 beam elements in this test use the corrected profile-axis mapping.

IMPORTANT
---------
This test deliberately remains B31T so that ONLY the axis correction is
being tested against v1.0.1.

If the remaining difference is small but systematic, the next comparison
will switch to B31E because Mecway's own native beam formulation is
Euler-Bernoulli.

RUN
---
1. Open the same test.liml.
2. Keep bridge.py and mecway_launcher.py together.
3. Run mecway_launcher.py.
4. Mecway solves first, then patched CCX B31T.

SEND BACK
---------
test_ccx_draft.mecway_compare.txt
test_ccx_draft.mecway_compare.csv

Nothing should be pushed to GitHub until this comparison is checked.
